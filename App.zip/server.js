
var express = require('express')
const session = require('express-session');
var cors = require('cors')
const jwt = require("jsonwebtoken");
const PORT = 8080;
var app = express()
const secretKey = "your-secret-key";

//configurações da aplicação
app.use(cors());
app.use(express.json());
app.use(session({
    secret: 'secret-key',
    resave: false,
    saveUninitialized: false,
  }));


const API_KEY = "264bb09ec4d858065cfb8860838a32ff";
const DNS = "https://api.themoviedb.org/3";



//emulando banco de dados
var dados = {
    usuarios: [
        {id: '1', nome:'Teste da Silva', email: 'teste@teste.com', senha: '1234', idade: '18'},        
    ]
}

//Função para gerar o token de acesso da sessão
const generateToken = (userID) => {
    return jwt.sign({userID}, secretKey, { expiresIn: 60 * 60});
};

//checagem de token de acesso
function verifyJWT(req, res, next){
    console.log('verify ', req.body)
    let token = req.body.sessionID
    if (!token) return res.status(401).json({ auth: false, message: 'No token provided.' });
    
    jwt.verify(token, secretKey, function(err, decoded) {
      if (err) return res.status(500).json({ auth: false, message: 'Failed to authenticate token.' });
      
      // se tudo estiver ok, salva na sessão para uso posterior
      req.session.usuarioID = decoded.userID;
      console.log('verify: ', req.session)
      next();
    });
}

//função para carregar dados do usuario a partir do ID
function findUserByID(userID){
    let encontrado = {}
    
    dados.usuarios.forEach((usuario)=>{
        console.log(usuario.id, userID)
        if(usuario.id==userID){
            encontrado = usuario
        }
    })
    
    return encontrado
}


app.post('/login', (req, res, next)=>{

    //o que veio de dados do front
    console.log( req.body)
 
    let logado = false
    let usuarioLogado = {}
    dados.usuarios.forEach((usuario)=>{
        if(usuario.email==req.body.email && usuario.senha==req.body.senha){
            logado = true
            usuarioLogado = usuario
        }
    })

    if(logado){
        //obter a sessao
        const sessionData = req.session;
        //gravar o id do usuario logado na sessao
        req.session.isLogado = true;
        req.session.usuarioID = usuarioLogado.id;
        console.log('login ', req.session)
        //gerar o token da sessão
        const token = generateToken(usuarioLogado.id);
        res.send({sessionID: token})        
    }else{
        res.send('Error....')
    }
        
})


app.get('/api/allCategories', async (req, res) => {
    const { adult } = req.query;
    const isAdultFilter = adult === 'true';

    const results = [];

    // Lista de categorias disponíveis
    const allCategories = [
        {
            name: "trending",
            title: "Em Alta",
            path: "/trending/all/week?api_key=" + API_KEY + "&language=pt-BR",
            isLarge: true,
        },
        {
            name: "netflixOriginals",
            title: "Originais Netflix",
            path: "/discover/tv?api_key=" + API_KEY + "&with_networks=213",
            isLarge: false,
        },
        {
            name: "topRated",
            title: "Populares",
            path: "/movie/top_rated?api_key=" + API_KEY + "&language=pt-BR",
            isLarge: false,
        },
        {
            name: "comedy",
            title: "Comédias",
            path: "/discover/tv?api_key=" + API_KEY + "&with_genres=35",
            isLarge: false,
        },
        {
            name: "romances",
            title: "Romances",
            path: "/discover/tv?api_key=" + API_KEY + "&with_genres=10749",
            isLarge: false,
        },
        {
            name: "documentaries",
            title: "Documentários",
            path: "/discover/tv?api_key=" + API_KEY + "&with_genres=99",
            isLarge: false,
        }
    ];

    try {
        // Buscar dados para cada categoria na lista allCategories
        for (const category of allCategories) {
            const response = await fetch(DNS + category.path);
            if (!response.ok) {
                throw new Error(`Erro na requisição para a categoria ${category.name}: ${response.statusText}`);
            }
            const data = await response.json();

            // Filtrar dados com base no parâmetro 'adult'
            const filteredData = isAdultFilter ? data.results.filter(item => item.adult === isAdultFilter) : data.results;

            results.push({
                name: category.name,
                title: category.title,
                path: category.path,
                isLarge: category.isLarge,
                data: filteredData // Adiciona todos os itens filtrados
            });
        }

        console.log(results);
        res.json(results);

    } catch (error) {
        res.status(500).json({ message: 'Erro ao buscar dados da API', error: error.message });
    }
});


app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});