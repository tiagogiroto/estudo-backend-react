import './App.css';
import Row from './components/Row'
import Banner from "./components/Banner"
import Nav from "./components/Nav"
import { useEffect, useState } from 'react';
import axios from 'axios';

function App() {

  const [data, setData] = useState([]); // Estado para armazenar os dados
  const [loading, setLoading] = useState(true); // Estado para gerenciar o carregamento
  const [error, setError] = useState(null); // Estado para armazenar erros

  useEffect(() => {
    const fetchData = async () => {
      try {

        const response = await axios.get('http://localhost:8080/api/allCategories');

        setData(response.data); // Armazenar os dados recebidos no estado
        setLoading(false); // Atualizar o estado de carregamento
      } catch (err) {
        console.error("Ops! Ocorreu um erro:", err);
        setError('Erro ao buscar dados'); // Armazenar o erro
        setLoading(false); // Atualizar o estado de carregamento
      }
    };

    fetchData(); // Chama a função assíncrona 

    
  }, [])

  console.log(data)

  return (

    <div>
      <Nav />
      <Banner />


      {data.map((category) => {
        return <Row
          key={category.name}
          title={category.title}
          isLarge={category.isLarge}
          path={category.path}
        /> 

      })}
       



    </div>
  );
}

export default App;